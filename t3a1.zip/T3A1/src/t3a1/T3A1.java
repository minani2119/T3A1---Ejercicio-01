package t3a1;

import java.util.Scanner;

public class T3A1 {

    
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
    public static void procesar(){
        Scanner scanner = new Scanner(System.in);
        Calificaciones calificaciones = new Calificaciones();
        
        System.out.println("Nombre:");
        String nombre = scanner.nextLine();
        calificaciones.setNombre(nombre);
        
        System.out.println("Apelido Paternp:");
        String apellidoPaterno = scanner.nextLine();
        calificaciones.setApellidoPaterno(apellidoPaterno);
        
        System.out.println("Apellido Materno:");
        String apellidoMaterno = scanner.nextLine();
        calificaciones.setApellidoMaterno(apellidoMaterno);
        
        System.out.println("Grupo:");
        String grupo = scanner.nextLine();
        calificaciones.setGrupo(grupo);
        
        System.out.println("Carrera:");
        String carrera = scanner.nextLine();
        calificaciones.setCarrera(carrera);
        
        System.out.println("Asignatura:");
        String asignatura = scanner.nextLine();
        calificaciones.setAsignatura(asignatura);
        
        System.out.println("Calificacion:");
        String calificacion = scanner.nextLine();
        calificaciones.setCalificacion(calificacion);
    }
     }